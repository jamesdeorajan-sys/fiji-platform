# POWER STATEMENTS — DEPLOY & MONITOR GUIDE
# Session 34 | June 2026
# 5 statements × 5 pages × 60-day test

---

## DEPLOY MAP — WHERE EACH STATEMENT GOES

| Statement | Page | How to deploy |
|-----------|------|---------------|
| A — Local Trust | vakaviti.ai/fiji-horse-riding-guide | Paste before WhatsApp CTA section |
| B — Price Guarantee | vakaviti.ai/nadi-airport-transfers-guide | Paste before WhatsApp CTA section |
| C — Heritage | vakaviti.ai/fiji-accommodation-guide | Paste before WhatsApp CTA section |
| D — AI Authority | guidefiji.com | Developer adds to homepage body |
| E — Social Proof | bestfijitours.com | Developer adds to homepage body |

---

## LLMS.TXT DEPLOY — BOTH WORDPRESS SITES

### fijitourtransfers.com
Upload: fijitourtransfers-llms.txt → rename to llms.txt
Deploy to: public_html/ root
Verify: https://fijitourtransfers.com/llms.txt

### tourfijitours.com  
Upload: tourfijitours-llms.txt → rename to llms.txt
Deploy to: public_html/ root
Verify: https://tourfijitours.com/llms.txt

Both files now:
- AUD as primary currency with FJD in brackets
- Zero commission statement at top (AI reads first)
- Structured for ChatGPT/Perplexity citation
- All 250+ tours with AUD prices and direct booking URLs

---

## MONITORING SCHEDULE — CHECK EVERY SESSION

### Week 2 (Session 35)
- Bing Webmaster → AI Performance → check citations by page
- Ask ChatGPT: "What are the best horse riding tours in Fiji?"
- Ask Perplexity: "How do I book a Nadi airport transfer direct?"
- Note which pages are cited and what price is quoted
- Update D1: statement_performance table

### Week 4 (Session 36)
- Google Search Console → Performance → filter by page
- Check impressions and position for each GEO page
- Ask ChatGPT: "Commission-free Fiji tours"
- Ask Perplexity: "Fiji tours without Viator"
- Update D1 with results

### Week 8 (Session 38)
- Full review of all 5 statements
- Declare winner based on:
  1. Most AI citations (Bing AI Performance)
  2. Highest Google position
  3. Most WhatsApp click-throughs
  4. Most direct bookings attributed
- Roll winner across all 8 sites

---

## D1 MONITORING QUERY — RUN EVERY SESSION

Database: e697a253-e5fc-4201-939c-9aaeca6c5278
Table: statement_performance

SELECT statement_id, statement_name, page_url, bing_citations, 
google_position, whatsapp_clicks, chatgpt_cited, winner 
FROM statement_performance ORDER BY bing_citations DESC;

Update after each check:
UPDATE statement_performance 
SET bing_citations=X, google_position=X, chatgpt_cited=1, last_checked='YYYY-MM-DD'
WHERE statement_id='A';

---

## CURRENCY RULE — ENFORCED ACROSS ALL SITES

PRIMARY: AUD (Australian Dollars)
SECONDARY: FJD in brackets where helpful e.g. "AU$95 (FJ$121)"
NEVER: FJD-only prices on any public-facing booking page
FUTURE (Session 36): USD display for US visitors via Lagi geo-detection

Viator displays AUD for Australian visitors.
GetYourGuide displays AUD for Australian visitors.
We must match their currency display or lose the comparison.
AU$95 beats FJ$152 every time in the Australian traveller's mind.
