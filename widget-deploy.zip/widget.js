/* ═══════════════════════════════════════════════════════
   VAKAVITI SENTINEL + META BRIDGE — Auto-activated v1
   Monitors all partner sites via data-site-id attribute
   ═══════════════════════════════════════════════════════ */
(function initVakavitiSentinel() {
  'use strict';
  var SENTINEL_URL = 'https://vakaviti-error-sentinel.helpronline.workers.dev/ingest';
  var SENTINEL_KEY = 'vk-sentinel-2026';
  var BRIDGE_URL   = 'https://vakaviti-leads-v2.helpronline.workers.dev/meta-bridge';
  var RAGE_THRESHOLD = 5;
  var RAGE_WINDOW_MS = 2000;
  var _recentErrors = {};
  var _clickLog = [];

  var _script = document.currentScript
    || document.querySelector('script[src*="widget.vakaviti.ai"]')
    || document.querySelector('script[data-site-id]');
  var SITE_ID = _script ? (_script.getAttribute('data-site-id') || 'unknown') : 'unknown';

  function _sid() {
    try {
      var s = sessionStorage.getItem('vk_sid');
      if (!s) { s = 'sid_' + Date.now() + '_' + Math.random().toString(36).slice(2,8); sessionStorage.setItem('vk_sid', s); }
      return s;
    } catch(e) { return 'sid_unknown'; }
  }

  function _device() {
    return /mobile|android|iphone|ipad|tablet/i.test(navigator.userAgent) ? 'mobile' : 'desktop';
  }

  function _send(payload) {
    var key = payload.error_type + '::' + payload.error_string;
    var now = Date.now();
    if (_recentErrors[key] && now - _recentErrors[key] < 30000) return;
    _recentErrors[key] = now;
    try {
      fetch(SENTINEL_URL, {
        method: 'POST', keepalive: true,
        headers: { 'Content-Type': 'application/json', 'x-sentinel-key': SENTINEL_KEY },
        body: JSON.stringify({ site_id: SITE_ID, session_id: _sid(), device_type: _device(), page_url: window.location.href, rage_clicks: payload.rage_clicks || 0, stack_trace: payload.stack_trace || '', error_type: payload.error_type, error_string: payload.error_string })
      }).catch(function(){});
    } catch(e) {}
  }

  function _bridge(intent) {
    try {
      var p = new URLSearchParams(window.location.search);
      var fbclid = p.get('fbclid') || '';
      var utm_source = p.get('utm_source') || '';
      var utm_campaign = p.get('utm_campaign') || '';
      if (!fbclid && !utm_source && !utm_campaign && !p.get('ref')) return;
      fetch(BRIDGE_URL, {
        method: 'POST', keepalive: true,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ site_id: SITE_ID, session_id: _sid(), landing_url: window.location.href, device_type: _device(), intent_type: intent, fbclid: fbclid, utm_source: utm_source, utm_medium: p.get('utm_medium') || '', utm_campaign: utm_campaign, utm_content: p.get('utm_content') || '', ref: p.get('ref') || '' })
      }).catch(function(){});
    } catch(e) {}
  }

  window.addEventListener('error', function(e) { _send({ error_type: 'uncaught_error', error_string: e.message || 'Unknown error', stack_trace: e.error ? e.error.stack || '' : '' }); }, { passive: true });
  window.addEventListener('unhandledrejection', function(e) { _send({ error_type: 'uncaught_error', error_string: 'Promise: ' + (e.reason && e.reason.message ? e.reason.message : String(e.reason)) }); }, { passive: true });

  var _origErr = console.error.bind(console);
  console.error = function() { _origErr.apply(console, arguments); var msg = Array.prototype.slice.call(arguments).map(function(a){ return typeof a === 'object' ? JSON.stringify(a) : String(a); }).join(' ').slice(0,500); _send({ error_type: 'console_error', error_string: msg }); };

  document.addEventListener('click', function(e) {
    var now = Date.now();
    _clickLog.push({ t: now, target: e.target });
    _clickLog = _clickLog.filter(function(c){ return now - c.t < RAGE_WINDOW_MS; });
    if (_clickLog.length >= RAGE_THRESHOLD) {
      var t = _clickLog[_clickLog.length-1].target;
      _send({ error_type: 'rage_click', error_string: 'Rage click on ' + (t.tagName || 'unknown').toLowerCase(), rage_clicks: _clickLog.length });
      _clickLog = [];
    }
  }, { passive: true });

  _bridge('page_view');
  var _path = window.location.pathname.toLowerCase();
  if (_path.includes('checkout') || _path.includes('cart')) _bridge('checkout');
  else if (_path.includes('booking') || _path.includes('st_tour')) _bridge('tour_view');

})();
/* ═══════════════════════════════════════════════════════
   END SENTINEL — Lagi Widget continues below
   ═══════════════════════════════════════════════════════ *//**
 * Vakaviti.ai — Lagi Widget v2
 * Served from Cloudflare Pages — widget.vakaviti.ai/widget.js
 */
(function () {
  'use strict';
  const LEGACY_DEFAULTS = {
    brandName: 'Fiji Tour Transfers',
    workerUrl: 'https://fiji-chat-widget.helpronline.workers.dev/',
    whatsappUrl: 'https://wa.me/61478886145',
    themeColor: '#0d4d6e',
    greetingText: null,
  };
  const WORKER_URL = 'https://fiji-chat-widget.helpronline.workers.dev/';
  let config = null;
  let conversation = [];
  let isOpen = false;
  let isLoading = false;
  let hasGreeted = false;
  let leadCaptured = false;
  let messageCount = 0;
  let leadFormShown = false;
  let sessionId = 'sess_' + Date.now().toString(36) + Math.random().toString(36).slice(2,7);

  async function boot() {
    const siteId = getSiteId();
    if (siteId) { config = await fetchConfig(siteId); }
    if (!config) {
      config = {
        siteId: null, partnerId: null,
        brandName: LEGACY_DEFAULTS.brandName,
        workerUrl: LEGACY_DEFAULTS.workerUrl,
        whatsappUrl: LEGACY_DEFAULTS.whatsappUrl,
        whatsappNumber: '+61 478 886 145',
        themeColor: LEGACY_DEFAULTS.themeColor,
        greetingText: null, isLegacy: true
      };
    }
    injectStyles();
    injectWidget();
    wireEvents();
  }

  function getSiteId() {
    if (window.VAKAVITI_SITE_ID) return window.VAKAVITI_SITE_ID;
    const script = document.getElementById('vk-widget-script') ||
      document.currentScript ||
      document.querySelector('script[data-site-id]');
    return script ? (script.getAttribute('data-site-id') || null) : null;
  }

  async function fetchConfig(siteId) {
    try {
      const res = await fetch(WORKER_URL + 'config?site_id=' + encodeURIComponent(siteId));
      if (!res.ok) return null;
      const d = await res.json();
      return {
        siteId, partnerId: d.partner_id || null,
        brandName: d.brand_name || 'Vakaviti',
        workerUrl: WORKER_URL,
        whatsappUrl: d.whatsapp_url || LEGACY_DEFAULTS.whatsappUrl,
        whatsappNumber: d.whatsapp_number || '',
        themeColor: d.theme_color || '#0d4d6e',
        greetingText: d.greeting_text || null,
        isLegacy: false
      };
    } catch { return null; }
  }

  function darken(hex, amt) {
    const n = parseInt(hex.replace('#',''), 16);
    const r = Math.max(0, (n>>16) - Math.round(255*amt));
    const g = Math.max(0, ((n>>8)&0xFF) - Math.round(255*amt));
    const b = Math.max(0, (n&0xFF) - Math.round(255*amt));
    return '#' + [r,g,b].map(v => v.toString(16).padStart(2,'0')).join('');
  }

  function escHtml(s) {
    return String(s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function renderMarkdown(text) {
    let html = escHtml(text);
    // Bold
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    // Links — using indexOf to avoid regex issues
    let result = '';
    let remaining = html;
    while (remaining.length > 0) {
      const lb = remaining.indexOf('[');
      if (lb === -1) { result += remaining; break; }
      const rb = remaining.indexOf('](', lb);
      if (rb === -1) { result += remaining; break; }
      const rp = remaining.indexOf(')', rb + 2);
      if (rp === -1) { result += remaining; break; }
      const linkText = remaining.slice(lb + 1, rb);
      const linkUrl  = remaining.slice(rb + 2, rp).trim();
      result += remaining.slice(0, lb);
      if (linkUrl.startsWith('http')) {
        if (linkUrl.includes('wa.me') || linkUrl.includes('whatsapp.com')) {
          result += '<br><a href="' + linkUrl + '" class="vk-wa-btn" target="_blank" rel="noopener">' + escHtml(linkText) + '</a>';
        } else {
          result += '<a href="' + linkUrl + '" target="_blank" rel="noopener">' + escHtml(linkText) + '</a>';
        }
      } else {
        result += remaining.slice(lb, rp + 1);
      }
      remaining = remaining.slice(rp + 1);
    }
    html = result || html;
    // Newlines
    html = html.split('\n\n').join('</p><p>');
    html = html.split('\n').join('<br>');
    if (!html.startsWith('<')) html = '<p>' + html + '</p>';
    return html;
  }

  function injectStyles() {
    if (document.getElementById('vk-widget-styles')) return;
    const tc = config.themeColor;
    const td = darken(tc, 0.15);
    const el = document.createElement('style');
    el.id = 'vk-widget-styles';
    el.textContent = [
      '#vk-chat-widget{--vk-ocean:' + tc + ';--vk-ocean-deep:' + td + ';position:fixed;bottom:20px;right:20px;z-index:999999;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;font-size:14px;line-height:1.5;color:#1a1a1a}',
      '#vk-chat-widget *{box-sizing:border-box;margin:0;padding:0}',
      '#vk-chat-launcher{width:60px;height:60px;border-radius:50%;background:var(--vk-ocean);color:#faf6f0;border:none;cursor:pointer;box-shadow:0 8px 32px rgba(8,51,74,0.18);display:flex;align-items:center;justify-content:center;transition:transform .2s,background .2s;position:relative}',
      '#vk-chat-launcher:hover{background:var(--vk-ocean-deep);transform:scale(1.05)}',
      '#vk-chat-launcher.open{background:#1a1a1a}',
      '#vk-chat-launcher svg{width:28px;height:28px}',
      '#vk-chat-panel{position:absolute;bottom:76px;right:0;width:380px;max-width:calc(100vw - 32px);height:580px;max-height:calc(100vh - 120px);background:#faf6f0;border-radius:16px;box-shadow:0 8px 32px rgba(8,51,74,0.18);display:none;flex-direction:column;overflow:hidden}',
      '#vk-chat-panel.open{display:flex}',
      '#vk-chat-header{padding:16px 20px;background:var(--vk-ocean);color:#faf6f0;display:flex;align-items:center;gap:12px}',
      '#vk-chat-header-title{font-weight:600;font-size:15px;flex:1}',
      '#vk-chat-header-sub{font-size:11px;opacity:.85;margin-top:2px}',
      '#vk-chat-close{background:none;border:none;color:#faf6f0;cursor:pointer;padding:4px;opacity:.8;display:flex;align-items:center}',
      '#vk-chat-messages{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:10px;background:#faf6f0}',
      '.vk-msg{max-width:85%;padding:10px 14px;border-radius:16px;font-size:14px;line-height:1.45;word-wrap:break-word}',
      '.vk-msg-user{align-self:flex-end;background:var(--vk-ocean);color:#faf6f0;border-bottom-right-radius:4px}',
      '.vk-msg-ai{align-self:flex-start;background:#eef4f7;color:#1a1a1a;border-bottom-left-radius:4px;border-left:3px solid var(--vk-ocean);padding-left:12px}',
      '.vk-msg-ai a{color:var(--vk-ocean);text-decoration:underline}',
      '.vk-wa-btn{display:inline-flex;align-items:center;gap:8px;margin-top:8px;padding:10px 18px;background:#25D366;color:#fff!important;border-radius:8px;text-decoration:none;font-size:13px;font-weight:500}',
      '.vk-wa-btn:hover{background:#1ebe5d}',
      '.vk-loading{align-self:flex-start;background:#eef4f7;border-left:3px solid var(--vk-ocean);padding:12px 16px;display:flex;gap:4px;border-radius:16px;border-bottom-left-radius:4px}',
      '.vk-loading span{width:6px;height:6px;border-radius:50%;background:var(--vk-ocean);opacity:.4;animation:vkpulse 1.2s infinite}',
      '.vk-loading span:nth-child(2){animation-delay:.2s}.vk-loading span:nth-child(3){animation-delay:.4s}',
      '@keyframes vkpulse{0%,80%,100%{opacity:.3;transform:scale(.85)}40%{opacity:1;transform:scale(1)}}',
      '#vk-chat-input-area{border-top:1px solid #ebe5d6;padding:12px 14px;background:#fffdf8;display:flex;flex-direction:column;gap:8px}',
      '#vk-chat-input-row{display:flex;gap:8px;align-items:flex-end}',
      '#vk-chat-input{flex:1;border:1px solid #d8d0c2;border-radius:18px;padding:9px 14px;font-family:inherit;font-size:14px;resize:none;max-height:100px;min-height:38px;background:#faf6f0;color:#1a1a1a;outline:none}',
      '#vk-chat-input:focus{border-color:var(--vk-ocean)}',
      '#vk-chat-send{background:var(--vk-ocean);color:#faf6f0;border:none;border-radius:50%;width:38px;height:38px;cursor:pointer;display:flex;align-items:center;justify-content:center}',
      '#vk-chat-send:disabled{opacity:.4;cursor:not-allowed}',
      '#vk-chat-wa{display:flex;align-items:center;justify-content:center;gap:6px;padding:7px 12px;background:transparent;border:1px solid #d8d0c2;border-radius:16px;color:#4a4a4a;text-decoration:none;font-size:12px;font-weight:500}',
      '#vk-chat-wa:hover{background:#25d366;border-color:#25d366;color:white}',
      '#vk-powered{text-align:center;font-size:10px;color:#8a8580;padding:4px 0 2px}',
      '#vk-powered a{color:inherit;text-decoration:none}',
    ].join('');
    document.head.appendChild(el);
  }

  function injectWidget() {
    if (document.getElementById('vk-chat-widget')) return;
    const w = document.createElement('div');
    w.id = 'vk-chat-widget';

    const launcher = document.createElement('button');
    launcher.id = 'vk-chat-launcher';
    launcher.setAttribute('aria-label', 'Open chat');
    launcher.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21 6h-2v9H6v2c0 .55.45 1 1 1h11l4 4V7c0-.55-.45-1-1-1zm-4 6V3c0-.55-.45-1-1-1H3c-.55 0-1 .45-1 1v14l4-4h10c.55 0 1-.45 1-1z"/></svg>';
    w.appendChild(launcher);

    const panel = document.createElement('div');
    panel.id = 'vk-chat-panel';
    panel.setAttribute('role', 'dialog');

    const header = document.createElement('div');
    header.id = 'vk-chat-header';
    header.innerHTML = '<div style="flex:1"><div id="vk-chat-header-title">' + escHtml(config.brandName) + '</div><div id="vk-chat-header-sub">Quick answers · anything Fiji</div></div>';
    const closeBtn = document.createElement('button');
    closeBtn.id = 'vk-chat-close';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>';
    header.appendChild(closeBtn);
    panel.appendChild(header);

    const messages = document.createElement('div');
    messages.id = 'vk-chat-messages';
    messages.setAttribute('aria-live', 'polite');
    panel.appendChild(messages);

    const inputArea = document.createElement('div');
    inputArea.id = 'vk-chat-input-area';

    const inputRow = document.createElement('div');
    inputRow.id = 'vk-chat-input-row';
    const textarea = document.createElement('textarea');
    textarea.id = 'vk-chat-input';
    textarea.placeholder = 'Ask me anything about Fiji...';
    textarea.rows = 1;
    inputRow.appendChild(textarea);
    const sendBtn = document.createElement('button');
    sendBtn.id = 'vk-chat-send';
    sendBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>';
    inputRow.appendChild(sendBtn);
    inputArea.appendChild(inputRow);

    const waLink = document.createElement('a');
    waLink.id = 'vk-chat-wa';
    waLink.href = config.whatsappUrl;
    waLink.target = '_blank';
    waLink.rel = 'noopener';
    waLink.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M.057 24l1.687-6.163a11.867 11.867 0 0 1-1.587-5.946C.16 5.335 5.495 0 12.05 0a11.817 11.817 0 0 1 8.413 3.488 11.824 11.824 0 0 1 3.48 8.414c-.003 6.557-5.338 11.892-11.893 11.892a11.9 11.9 0 0 1-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z"/></svg> Continue on WhatsApp';
    inputArea.appendChild(waLink);

    const powered = document.createElement('div');
    powered.id = 'vk-powered';
    powered.innerHTML = '<a href="https://vakaviti.ai" target="_blank" rel="noopener">powered by vakaviti.ai</a>';
    inputArea.appendChild(powered);
    panel.appendChild(inputArea);
    w.appendChild(panel);
    document.body.appendChild(w);
  }

  function appendMessage(role, text) {
    const messages = document.getElementById('vk-chat-messages');
    const div = document.createElement('div');
    div.className = 'vk-msg vk-msg-' + role;
    div.innerHTML = role === 'ai' ? renderMarkdown(text) : escHtml(text);
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
    return div;
  }

  function appendReferralBtn(btn) {
    if (!btn || !btn.url) return;
    const messages = document.getElementById('vk-chat-messages');
    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'margin-top:4px;padding-left:15px;';
    const a = document.createElement('a');
    a.href = btn.url; a.target = '_blank'; a.rel = 'noopener';
    a.className = 'vk-wa-btn';
    a.style.cssText = 'display:inline-flex;align-items:center;gap:8px;padding:10px 18px;background:#25D366;color:#fff;border-radius:8px;text-decoration:none;font-size:13px;font-weight:500;';
    a.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M.057 24l1.687-6.163a11.867 11.867 0 0 1-1.587-5.946C.16 5.335 5.495 0 12.05 0a11.817 11.817 0 0 1 8.413 3.488 11.824 11.824 0 0 1 3.48 8.414c-.003 6.557-5.338 11.892-11.893 11.892a11.9 11.9 0 0 1-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z"/></svg> ' + escHtml(btn.label || 'Contact on WhatsApp');
    wrapper.appendChild(a);
    messages.appendChild(wrapper);
    messages.scrollTop = messages.scrollHeight;
  }

  function showLoading() {
    const messages = document.getElementById('vk-chat-messages');
    const div = document.createElement('div');
    div.className = 'vk-loading'; div.id = 'vk-loading';
    div.innerHTML = '<span></span><span></span><span></span>';
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
  }
  function hideLoading() { const el = document.getElementById('vk-loading'); if(el) el.remove(); }
  function setSendDisabled(d) {
    document.getElementById('vk-chat-send').disabled = d;
    document.getElementById('vk-chat-input').disabled = d;
  }

  function maybeShowLeadForm() {
    if (leadCaptured || leadFormShown || messageCount < 3) return;
    leadFormShown = true;
    const messages = document.getElementById('vk-chat-messages');
    const form = document.createElement('div');
    form.id = 'vk-lead-form';
    form.style.cssText = 'margin-top:8px;padding:10px 12px;background:#f5ede0;border-radius:10px;border:1px solid #d8d0c2;';
    form.innerHTML = '<p style="font-size:13px;color:#4a4a4a;margin-bottom:6px;">Want us to follow up? Leave your name and we\'ll reach out.</p>' +
      '<div style="display:flex;gap:6px;margin-bottom:6px;">' +
      '<input style="flex:1;border:1px solid #d8d0c2;border-radius:8px;padding:7px 10px;font-size:13px;" id="vk-lead-name" placeholder="Your name" />' +
      '<input style="flex:1;border:1px solid #d8d0c2;border-radius:8px;padding:7px 10px;font-size:13px;" id="vk-lead-email" placeholder="Email or WhatsApp" /></div>' +
      '<div style="display:flex;gap:6px;">' +
      '<button id="vk-lead-submit" style="background:#0d4d6e;color:#fff;border:none;border-radius:8px;padding:7px 14px;font-size:13px;cursor:pointer;">Send to team</button>' +
      '<button id="vk-lead-skip" style="background:none;border:none;color:#8a8580;font-size:12px;cursor:pointer;text-decoration:underline;">Skip</button></div>';
    messages.appendChild(form);
    messages.scrollTop = messages.scrollHeight;
    document.getElementById('vk-lead-submit').onclick = submitLeadForm;
    document.getElementById('vk-lead-skip').onclick = function() { form.remove(); };
  }

  function submitLeadForm() {
    const name    = (document.getElementById('vk-lead-name').value || '').trim();
    const contact = (document.getElementById('vk-lead-email').value || '').trim();
    if (!name && !contact) return;
    leadCaptured = true;
    document.getElementById('vk-lead-form').remove();
    fetch(config.workerUrl + 'lead', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ site_id: config.siteId, partner_id: config.partnerId, session_id: sessionId, name, contact, conversation_snapshot: conversation.slice(-6) })
    }).catch(function(){});
    appendMessage('ai', 'Vinaka ' + (name||'there') + '! The ' + config.brandName + ' team will be in touch shortly. Sota tale! 🌺');
  }

  function openPanel() {
    isOpen = true;
    document.getElementById('vk-chat-panel').classList.add('open');
    document.getElementById('vk-chat-launcher').classList.add('open');
    if (!hasGreeted) {
      hasGreeted = true;
      const greeting = config.greetingText ||
        'Bula! I\'m Lagi, your AI guide for ' + config.brandName + '. I can answer questions about Fijian language, culture, transfers, tours and anything Fiji — instantly. 🌺\n\nWhat can I help with?';
      appendMessage('ai', greeting);
    }
    setTimeout(function() { const el = document.getElementById('vk-chat-input'); if(el) el.focus(); }, 250);
  }

  function closePanel() {
    isOpen = false;
    document.getElementById('vk-chat-panel').classList.remove('open');
    document.getElementById('vk-chat-launcher').classList.remove('open');
  }

  async function sendMessage() {
    if (isLoading) return;
    const input = document.getElementById('vk-chat-input');
    const text = input.value.trim();
    if (!text) return;
    appendMessage('user', text);
    input.value = ''; input.style.height = 'auto';
    conversation.push({role:'user', content:text});
    messageCount++;
    isLoading = true; setSendDisabled(true); showLoading();
    try {
      const res = await fetch(config.workerUrl, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ messages: conversation, site_id: config.siteId, partner_id: config.partnerId, session_id: sessionId })
      });
      hideLoading();
      const data = await res.json().catch(function(){ return null; });
      if (!data) { appendMessage('ai', 'Sorry, connection issue. Please try again.'); return; }
      const reply = data.message || "Sorry, I didn't catch that.";
      appendMessage('ai', reply);
      if (data.type === 'reply') { conversation.push({role:'assistant', content:reply}); }
      if (data.referral_btn) { appendReferralBtn(data.referral_btn); }
      maybeShowLeadForm();
    } catch(e) {
      hideLoading();
      appendMessage('ai', 'Connection issue. Please try again or WhatsApp us.');
    } finally {
      isLoading = false; setSendDisabled(false);
      const el = document.getElementById('vk-chat-input'); if(el) el.focus();
    }
  }

  function wireEvents() {
    document.getElementById('vk-chat-launcher').addEventListener('click', function() { isOpen ? closePanel() : openPanel(); });
    document.getElementById('vk-chat-close').addEventListener('click', closePanel);
    document.getElementById('vk-chat-send').addEventListener('click', sendMessage);
    document.getElementById('vk-chat-input').addEventListener('keydown', function(e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
    });
    document.getElementById('vk-chat-input').addEventListener('input', function() {
      const el = document.getElementById('vk-chat-input');
      el.style.height = 'auto';
      el.style.height = Math.min(el.scrollHeight, 100) + 'px';
    });
  }

  function init() { if (document.getElementById('vk-chat-widget')) return; boot(); }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else { init(); }
})();
